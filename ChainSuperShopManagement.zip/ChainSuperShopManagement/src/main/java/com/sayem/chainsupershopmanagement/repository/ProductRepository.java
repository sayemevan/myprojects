/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sayem.chainsupershopmanagement.repository;

import com.sayem.chainsupershopmanagement.model.Product;
import com.sayem.chainsupershopmanagement.service.ProductService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductRepository implements ProductService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Product> viewAllProduct() {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Product> plist = session.createQuery("from Product").list();
        transaction.commit();
        session.close();
        
        return plist;
    }

    @Override
    public Product viewOneProduct(int prid) {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Product product = (Product)session.get(Product.class, prid);
        transaction.commit();
        session.close();
        
        return product;
    }

    @Override
    public Product viewProductByName(String pname) {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(Product.class);
        crit.add(Restrictions.eq("pname", pname));
        Product product = (Product)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return product;
    }

    @Override
    public Product insertProduct(Product product) {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(product);
        transaction.commit();
        session.close();
        
        return product;
    }

    @Override
    public void updateProduct(Product product) {
        
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(product);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteProduct(int prid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Product product = (Product)session.get(Product.class, prid);
        session.delete(product);
        transaction.commit();
        session.close();
    }

    @Override
    public List<Product> viewAllProductName() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Product> plist = session.createQuery("select p.pname from Product p").list();
        transaction.commit();
        session.close();
        
        return plist;
    }
    
}
