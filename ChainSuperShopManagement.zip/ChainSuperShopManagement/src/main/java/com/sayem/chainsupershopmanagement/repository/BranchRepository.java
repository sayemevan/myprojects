/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sayem.chainsupershopmanagement.repository;

import com.sayem.chainsupershopmanagement.model.Branchinfo;
import com.sayem.chainsupershopmanagement.model.Product;
import com.sayem.chainsupershopmanagement.service.BranchService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BranchRepository implements BranchService{
    
    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Branchinfo> viewAllBranch() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Branchinfo> branchlist = session.createQuery("from Branchinfo").list();
        transaction.commit();
        session.close();
        
        return branchlist;
    }

    @Override
    public List<Branchinfo> viewAllBranchLocation() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Branchinfo> branchlist = session.createQuery("select b.blocation from Branchinfo b").list();
        transaction.commit();
        session.close();
        
        return branchlist;
    }

    @Override
    public Branchinfo viewOneBranch(int bid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Branchinfo branch = (Branchinfo)session.get(Branchinfo.class, bid);
        transaction.commit();
        session.close();
        
        return branch;
    }

    @Override
    public Branchinfo viewBranchByLocation(String bname) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(Branchinfo.class);
        crit.add(Restrictions.eq("blocation", bname));
        Branchinfo branch = (Branchinfo)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return branch;
    }

    @Override
    public Branchinfo insertBranchLocation(Branchinfo branch) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(branch);
        transaction.commit();
        session.close();
        
        return branch;
    }

    @Override
    public void updateBranch(Branchinfo branch) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(branch);
        transaction.commit();
        session.close();
    }

    @Override
    public void deleteBranch(int bid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Branchinfo branch = (Branchinfo)session.get(Branchinfo.class, bid);
        session.delete(branch);
        transaction.commit();
        session.close();
    }
    
}
