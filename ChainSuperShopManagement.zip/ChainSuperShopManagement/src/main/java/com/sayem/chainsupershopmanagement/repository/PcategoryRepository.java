/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sayem.chainsupershopmanagement.repository;

import com.sayem.chainsupershopmanagement.model.Pcategory;
import com.sayem.chainsupershopmanagement.service.PcategoryService;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PcategoryRepository implements PcategoryService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public List<Pcategory> viewAllPcategory() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Pcategory> pcatlist = session.createQuery("from Pcategory").list();
        transaction.commit();
        session.close();
        
        return pcatlist;
    }

    @Override
    public Pcategory viewOneCategory(int catid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Pcategory pcat = (Pcategory)session.get(Pcategory.class, catid);
        transaction.commit();
        session.close();
        
        return pcat;
    }

    @Override
    public Pcategory viewCategoryByName(String cname) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Criteria crit = session.createCriteria(Pcategory.class);
        crit.add(Restrictions.eq("catname", cname));
        Pcategory pcat = (Pcategory)crit.uniqueResult();
        transaction.commit();
        session.close();
        
        return pcat;
    }

    @Override
    public Pcategory insertCategory(Pcategory pcat) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.save(pcat);
        transaction.commit();
        session.close();
        
        return pcat;
    }

    @Override
    public void deleteCategory(int catid) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        Pcategory pcat = (Pcategory)session.get(Pcategory.class, catid);
        session.delete(pcat);
        transaction.commit();
        session.close();
    }

    @Override
    public void updateCategory(Pcategory pcat) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        session.update(pcat);
        transaction.commit();
        session.close();
    }

    @Override
    public List<Pcategory> viewAllPcategoryName() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.getTransaction();
        transaction.begin();
        List<Pcategory> pcatlist = session.createQuery("select p.catname from Pcategory p").list();
        transaction.commit();
        session.close();
        
        return pcatlist;
    }

    
}
